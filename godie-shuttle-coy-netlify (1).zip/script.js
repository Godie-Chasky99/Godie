document.addEventListener("DOMContentLoaded", function () {
  const form = document.querySelector("form");

  form.addEventListener("submit", function (e) {
    e.preventDefault();

    const name = form.querySelector('input[placeholder="Full Name"]').value.trim();
    const email = form.querySelector('input[placeholder="Email"]').value.trim();
    const pickup = form.querySelector('input[placeholder="Pick-up Location"]').value.trim();
    const dropoff = form.querySelector('input[placeholder="Drop-off Location"]').value.trim();
    const date = form.querySelector('input[type="date"]').value;
    const vehicle = form.querySelector("select").value;

    if (!name || !email || !pickup || !dropoff || !date || !vehicle) {
      alert("Please fill in all fields.");
      return;
    }

    const message = `Booking Request:
    Name: ${name}
    Email: ${email}
    Pick-up: ${pickup}
    Drop-off: ${dropoff}
    Date: ${date}
    Vehicle: ${vehicle}`;

    const encodedMessage = encodeURIComponent(message);
    const whatsappURL = `https://wa.me/27606736476?text=${encodedMessage}`;

    window.open(whatsappURL, "_blank");

    form.reset();
  });
});
